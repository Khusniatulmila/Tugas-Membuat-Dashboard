<p></p>

<body>
    <center><font size="+3" face="arial">Sistem Informasi Perpustakaan</font></center>
    <center><font size="+3" face="arial">SMK Negeri 1 Purwosari</font></center>
</body>