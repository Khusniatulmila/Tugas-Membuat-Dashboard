<?php  
	$koneksi = new mysqli("localhost","root","","db_perpustakaan");


	echo = $_POST['judul'];
?>